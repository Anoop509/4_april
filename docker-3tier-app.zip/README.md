# Docker 3-Tier App (Without Docker Compose)

## 🚀 Steps to Run

### 1. Create Network
docker network create my-network

### 2. Run MySQL
docker run -d \
--name mysql-db \
--network my-network \
-e MYSQL_ROOT_PASSWORD=root123 \
-e MYSQL_DATABASE=testdb \
-p 3306:3306 \
mysql:8.0

### 3. Build Backend
cd backend
docker build -t backend-app .

### 4. Run Backend
docker run -d \
--name backend \
--network my-network \
-e DB_HOST=mysql-db \
-e DB_USER=root \
-e DB_PASSWORD=root123 \
-e DB_NAME=testdb \
-p 5000:5000 \
backend-app

### 5. Build Frontend
cd ../frontend
docker build -t frontend-app .

### 6. Run Frontend
docker run -d \
--name frontend \
--network my-network \
-p 3000:80 \
frontend-app
