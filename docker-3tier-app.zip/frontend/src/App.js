function App() {
  return (
    <div style={{ textAlign: "center", marginTop: "50px" }}>
      <h1>🚀 Docker 3-Tier App</h1>
      <p>Frontend chal raha hai ✅</p>
    </div>
  );
}

export default App;